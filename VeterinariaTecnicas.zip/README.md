# Veterinaria
This is the "Veterinaria" project from UdeA's "Tecnicas de Programación y Laboratorio" course, taken in the second half of 2023
